# Register your receivers here

from django.dispatch import receiver
import datetime
from datetime import date

from pretix.base.signals import validate_cart

@receiver(validate_cart, dispatch_uid='pretix_dodentocht_validate_cart')
def dt_validate_cart(sender, **kwargs):
    for index, position in enumerate(kwargs['positions']):
        for answer in position.answers.all():
            if answer.question.identifier == 'dt_dateofbirth':
                maxDateOfBirth = date(date.today().year - 15, 1, 1)
                dateOfBirth = datetime.strptime(str(answer), '%Y-%m-%d').date()
                if dateOfBirth >= maxDateOfBirth:
                    raise CartError(_('You are too young, you must turn 16 in {0}').format(date.today().year))